var test = require('../');

test('only2 test 1', function (t) {
    t.end();
});

test.only('only2 test 2', function (t) {
    t.end();
});
