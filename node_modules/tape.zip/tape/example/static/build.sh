#!/bin/bash
browserify ../timing.js -o bundle.js
